import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _b30ca2ee = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _ad5a1804 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _fd7857ac = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _18c6422a = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _dd7bd87c = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _caaa5668 = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _00def512 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _b30ca2ee,
    children: [{
      path: "",
      component: _ad5a1804,
      name: "home"
    }, {
      path: "/login",
      component: _fd7857ac,
      name: "login"
    }, {
      path: "/register",
      component: _fd7857ac,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _18c6422a,
      name: "profile"
    }, {
      path: "/settings",
      component: _dd7bd87c,
      name: "settings"
    }, {
      path: "/editor",
      component: _caaa5668,
      name: "editor"
    }, {
      path: "/editor/:slug",
      component: _caaa5668,
      name: "editor-edit"
    }, {
      path: "/article/:slug",
      component: _00def512,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
